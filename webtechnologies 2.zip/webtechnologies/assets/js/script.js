function scrollToDown() {
           window.scrollTo(900, 900);
       }
//Mouseover
$(document).ready(function(){
  $("h2").mouseover(function(){
    $("h2").css("color", "#D3D3D3");
  });
  $("h2").mouseout(function(){
    $("h2").css("color", "#000000");
  });
});
//Keydown
$(document).ready(function(){
  $("input").keydown(function(){
    $("input").css("background-color", "#ffff00");
  });
  $("input").keyup(function(){
    $("input").css("background-color", "#000000");
  });
});
//animation
var textWrapper = document.querySelector('.ml3');
textWrapper.innerHTML = textWrapper.textContent.replace(/\S/g, "<span class='letter'>$&</span>");

anime.timeline({loop: true})
  .add({
    targets: '.ml3 .letter',
    opacity: [0,1],
    easing: "easeInOutQuad",
    duration: 2250,
    delay: (el, i) => 150 * (i+1)
  }).add({
    targets: '.ml3',
    opacity: 0,
    duration: 1000,
    easing: "easeOutExpo",
    delay: 1000
  });

  //Sound
function play(){
  var audio = new Audio('sounds/10e1076dfd6c701 (1).mp3');
  audio.play();
};
